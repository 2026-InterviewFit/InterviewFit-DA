def settings():
    return None